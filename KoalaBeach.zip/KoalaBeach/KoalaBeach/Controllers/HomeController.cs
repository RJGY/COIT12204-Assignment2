﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using KoalaBeach.Models;

namespace KoalaBeach.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index()
        {
            return View();
        }
        public ViewResult Login()
        {
            return View();
        }
        public ViewResult Register()
        {
            return View();
        }

        [Route("/Catalog/{type}")]
        public ViewResult Catalog(String type)
        {
            ViewBag.Type = type;
            return View();
        }

        public ViewResult Catalog()
        {
            return View();
        }

        public ViewResult Contact()
        {
            return View();
        }
    }
}
